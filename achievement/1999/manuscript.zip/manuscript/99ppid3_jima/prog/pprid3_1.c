/*****************************************************************************/
/*    Theme   : ��Δ�r�f�[�^�ɑ΂���ˉe�ǐՂh�c�R                         */
/*    Number  : 650907                  �@�@�@�@�@�@                         */
/*    Author  : �،��@�q�@�@                                                 */
/*    Contents: �P��ڂ̎ˉe�x�N�g���̎Z�o�@�@�@�@                           */
/*    Language: Borland C++                                                  */
/*    Name    : pprid3_1.c			                                             */
/*****************************************************************************/

#include<conio.h>
#include<conio.h>
#include<graphics.h>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<values.h>

/***** Constants *****/
#define       J  48	/* �f�[�^��   */
#define       N   3	/* �f�[�^������ */

/* READ/WRITE file */
#define   i_file1  "mu_av.yel"/*��Δ�r�lmu*/
#define   i_file2  "../x.dat"/*�����ϗ�x*/
#define   o_file1  "pprid3_1.yel"
		/*�����ϗ�x�C�ˉey�C�����ϗ�f*/
#define   bgi_file "c:\\tc4\\bgi"

/********* Global Variable ***********************/
float  mu[J][J];     /* ��Δ�r�s��             */
float   x[J][N];     /* �����ϗ�                 */
float      y[J];     /* ���̂��ɂ�鐳�ˉe       */
float      p[N];     /* �ˉe�x�N�g��             */
float 	   f[J];     /* �N���XB�ɑ�����x��      */
float    f_n[J];     /* ���������             */
float    g_n[J];     /* �������G              */
float  sb[N][N];     /*   ����                   */
float  ss[N][N];     /*   ����                   */
float    lambda;     /* �ŗL�l                   */

/***** Function **********************************/
void r_file(void);
void calc_fg(void);
void henkan_f(void);
void calc_sigma(void);
void calc_p(void);
void calc_inv(float inv_sb[][N]);
void powermethod(float a[][N],float ev[]);
void calc_y(void);
void w_file(void);
void initialgraph(void);
void display(void);

/***************************************************/
void main(void)
{
	r_file(); /* �f�[�^�̓Ǎ� */
	calc_fg(); /* ���C���̎Z�o */
	henkan_f(); /* ���̕ϊ� */
	calc_sigma(); /* ��B�A��S�̎Z�o */
	calc_p(); /* ���̎Z�o */
	calc_y(); /* ���̎Z�o */
	w_file(); /* �f�[�^�̏��o */
	display(); /* �ˉe���ʂ̕\�� */
}  /* end of main */

/********************/
/* �f�[�^�̓ǂݍ��� */
/********************/
void r_file(void)
{
	int i,j1,j2;
	FILE *data1,*data2;

	data1 = fopen(i_file1,"r"); /* mu�̃t�@�C�� */
		if(data1 == NULL)
		{
			printf("\n i_file1 is not used!! "); exit(1);
		}
	data2 = fopen(i_file2,"r"); /* x�̃t�@�C�� */
		if(data2 == NULL)
		{
			printf("\n i_file2 is not used!! "); exit(1);
		}

	for(j1=0;j1<J;j1++)
	{
		for(j2=0;j2<J;j2++)
		{
			fscanf(data1," %f",&mu[j1][j2]);
		}
	}
	for(j1=0;j1<J;j1++)
	{
		 for(i=0;i<N;i++)
		 {
			fscanf(data2," %f",&x[j1][i]);
		 }
	}
	fclose(data1);
	fclose(data2);
}/* end of r_file */

/*************/
/* f�̎Z�o */
/*************/
void calc_fg(void)
{
	int j1,j2;

	for(j1=0;j1<J;j1++)
	{
		for(f[j1] = 0.0,j2=0;j2<J;j2++)
		{
			if(j1!=j2) /* �Ίp�v�f�͖��� */
			{
				f[j1] += mu[j1][j2];
			}
		}
	}
}
/* end of calc_fg */

/************/
/* ��,G�̕ϊ� */
/************/
void henkan_f(void)
{
	int j;
	float fmax,fmin; /* ���̍ő�A�ŏ��l */

	fmax = -999.9; fmin = 999.9;

	for(j=0;j<J;j++)
	{
		if(f[j]<fmin)
		{
			fmin = f[j];
		}
		if(f[j]>fmax)
		{
			fmax = f[j];
		}
	}

	for(j=0;j<J;j++)
	{
		f_n[j] = (f[j] - fmin) /( fmax - fmin);
		g_n[j] = 1.0 - f_n[j];
	}

} /* end of henkan_f */

/*****************/
/* ��B,��S�̎Z�o */
/*****************/
void calc_sigma(void)
{
	int i,i1,i2,j;
	float x_bar[N]; /* �N���X B ������ */
	float F;        /* ��Δ�r�̑��� */

	for(F=0.0,j=0;j<J;j++)
	{
		F += f_n[j];
	}

	for(i=0;i<N;i++)
	{
		for(x_bar[i]=0.0,j=0;j<J;j++)
		{
			x_bar[i] += f_n[j] * x[j][i] / F;
		}
	}
	for(i1=0;i1<N;i1++)
	{
		for(i2=0;i2<N;i2++)
		{
			for(sb[i1][i2] = 0.0,j=0;j<J;j++)
			{
				sb[i1][i2] += f_n[j] * (x[j][i1]-x_bar[i1]) * (x[j][i2]-x_bar[i2]) / F;
			}
		}
	}
	for(i1=0;i1<N;i1++)
	{
		for(i2=0;i2<N;i2++)
		{
			for(ss[i1][i2] = 0.0,j=0;j<J;j++)
			{
				ss[i1][i2] += g_n[j] * (x[j][i1]-x_bar[i1]) * (x[j][i2]-x_bar[i2]) /(48.0-F);
			}
		}
	}
}/* end of calc_sigma */

/***********/
/* p�̎Z�o */
/***********/
void calc_p(void)
{
	int i1,i2,i3;
	float m[N][N];      /* �t��B * ��S */
	float inv_sb[N][N]; /* �t��B       */
	calc_inv(inv_sb); /* �t��B�̎Z�o */

	for(i1=0;i1<N;i1++)
	{
		for(i2=0;i2<N;i2++)
		{
			for(m[i1][i2] = 0.0,i3=0;i3<N;i3++)
			{
				m[i1][i2] += inv_sb[i1][i3] * ss[i3][i2];
			}
		}
	}
	powermethod(m,p); /* �ˉe�x�N�g���̎Z�o */
} /* end of calc_p */

/****************/
/* �t�s��̎Z�o */
/****************/
void calc_inv(float inv_sb[][N])
{
	int i1,i2,i3;
	float b[N][2*N];
	float bm,bb,p;
	int im;

	for(i1=0;i1<N;i1++)
	{
		for(i2=0;i2<N;i2++)
		{
			b[i1][i2] =  sb[i1][i2];
			if(i1==i2)
				b[i1][N+i2] =1.0;
			else
				b[i1][N+i2] =0.0;
		}
	}
	for(i1=0;i1<N;i1++)
	{
		if(i1==N-1)
		{goto label1;}

		bm=fabs(b[i1][i1]);
		im=i1;
		for(i2=i1+1;i2<N;i2++)
		{
			bb=fabs(b[i2][i1]);
			if(bm<bb){bm=bb; im=i2;}
		}
		if(i1==im){goto label1;}

		for(i2=0;i2<N*2;i2++)
		{
			bb=b[i1][i2];
			b[i1][i2] = b[im][i2];
			b[im][i2] = bb;
		}
		label1:
		p = b[i1][i1];
		for(i2=0;i2<N*2;i2++)
		{
		b[i1][i2] /= p;
		}
		for(i2=0;i2<N;i2++)
	{
			if(b[i2][i1] ==0.0 || i2==i1){goto label2;}
			p= b[i2][i1];
			for(i3=i1;i3<N*2;i3++)
			{
				b[i2][i3] -= p * b[i1][i3];
			}
			label2: printf(" ");
		}
	}
	for(i1=0;i1<N;i1++)
	{
		for(i2=0;i2<N;i2++)
		{
			inv_sb[i1][i2] = b[i1][N+i2];
		}
	}
}/* end of inverse */

/****************************************/
/* �ׂ���@�ɂ��ő�ŗL�x�N�g���̎Z�o */
/****************************************/
void powermethod(float a[][N],float ev[])
{
	int i1,i2,i3;
	float ev_dash[N];
	float q; /* �ŗL�x�N�g���̃m���� */
	int kaisu;

	kaisu = 1000; /* �p���[���\�b�h�̌v�Z�� */

	for(i2=0;i2<N;i2++){ ev[i2] = 1.0; }

	for(i3=0;i3<kaisu;i3++)
	{
		for(i1=0;i1<N;i1++)
		{
			for(ev_dash[i1] = 0.0,i2=0;i2<N;i2++)
			{
				ev_dash[i1] += a[i1][i2] * ev[i2];
			}
		}
		lambda = -999.0;
		for(i2=0;i2<N;i2++)
		{
			if(ev_dash[i2]>lambda)
				lambda = ev_dash[i2];
		}
		for(i2=0;i2<N;i2++)
		{
			ev[i2] = ev_dash[i2] / lambda;
		}
	}
	for(q=0,i2=0;i2<N;i2++)
	{
		q += pow(ev[i2],2.0 );
	}
	for(i2=0;i2<N;i2++)
	{
		ev[i2] /= sqrt(q);
	}
}/* end of powermethod */

/***********/
/* y�̎Z�o */
/***********/
void calc_y(void)
{
	int i,j;

	for(j=0;j<J;j++)
	{
		y[j] = 0.0;
		for(i=0;i<N;i++)
		{
			y[j] += p[i] * x[j][i];
		}
	}
} /* end of calc_y */

/********************/
/* �f�[�^�̏����o�� */
/********************/
void w_file(void)
{
	int i,j1;
	FILE *data;

	data = fopen(o_file1,"w");
		if(data == NULL)
		{
			printf("\n o_file1 is not used!! ");exit(1);
		}
	for(j1=0;j1<J;j1++)
	{
		for(i=0;i<N;i++)
		{
			fprintf(data," %f ",x[j1][i]);
		}
		fprintf(data," %f %f \n",y[j1],f_n[j1]);
	}
	for(i=0;i<N;i++)
	{
		fprintf(data,"\n %f",p[i]);
	}
	fclose(data);
} /* w_file */

/****************/
/* �f�[�^�̕\�� */
/****************/
void display(void)
{
	int i,j;
	int y_dash,z_dash;

	initialgraph();
	clrscr();

	/* ���̕`�� */
	setcolor(WHITE);
	line(290,200,590,200); line(440,50,440,350);
	rectangle(290,50,590,350);
	settextjustify(1,2);
	outtextxy(290,350,"0.0"); outtextxy(440,350,"0.5");
	outtextxy(590,350,"1.0");
	settextjustify(2,1);
	outtextxy(290,200,"0.5");outtextxy(290,50,"1.0");
	settextjustify(1,0);
	outtextxy(440,50,"(y_f) Eigenvalue Method");

	/* �f�B�X�v���C��ł̍��W�Z�o�y�ѓ_�̕`�� */
	setcolor(LIGHTBLUE);
	for(j=0;j<J;j++)
	{
		y_dash = (int)(300 * y[j] + 290);
		z_dash = (int)(350 - 300 * (f_n[j]));
		circle(y_dash,z_dash,2);
	}
	for(i=0;i<N;i++)
	{
		printf("\np[%d] = %f",i,p[i]);
	}
	getch();
} /* end of display */

/************************/
/* �O���t�B�b�N�̏����� */
/************************/
void initialgraph(void)
{
	int gdriver = DETECT, gmode, errorcode;
	initgraph(&gdriver, &gmode,bgi_file);
	errorcode = graphresult();

	if (errorcode != grOk)
	{
		printf("Graphics error: %s\n", grapherrormsg(errorcode));
		printf("Press any key to halt:");
		getch(); exit(1);
	}
} /* end of initgraph */
