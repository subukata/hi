/*****************************************************************************/
/*    Theme   : ��Δ�r�f�[�^�ɑ΂���ˉe�ǐՂh�c�R                         */
/*    Number  : 650907                  �@�@�@�@�@�@                         */
/*    Author  : �،��@�q�@�@                                                 */
/*    Contents: �X�v���C���֐����T�̎��̃X�v���C���̒l�̎Z�o			�@�@�@�@ */
/*    Language: Borland C++                                                  */
/*    Name    : nbsp5.c			                                             		 */
/*****************************************************************************/
#include<stdio.h>
#include<graphics.h>
#include<stdlib.h>
#include<math.h>

/************Constants*************/
#define N 5	/*B�X�v���C���֐��̐�*/


/********global variables******/
extern float qq[N+3];


float bsp_c(float xxx ,int i) /* xxx:y[],i:s_number*/
{
	 float bsp;

	 bsp=0.0;


	 if((qq[i]<=xxx)&&(xxx<qq[i+1]))
	 {
		 bsp = (xxx-qq[i])*(xxx-qq[i])/
			((qq[i+1]-qq[i])*(qq[i+2]-qq[i]));
	 }
	 if((qq[i+1]<=xxx)&&(xxx<qq[i+2]))
	 {
		 bsp = ((xxx-qq[i])*(qq[i+2]-xxx))/
				 ((qq[i+2]-qq[i])*(qq[i+2]-qq[i+1]))
			   +((xxx-qq[i+1])*(qq[i+3]-xxx))/
				 ((qq[i+2]-qq[i+1])*(qq[i+3]-qq[i+1]));
	 }
	 if((qq[i+2]<=xxx)&&(xxx<qq[i+3]))
	 {
		 bsp = (qq[i+3]-xxx)*(qq[i+3]-xxx)/
			((qq[i+3]-qq[i+2])*(qq[i+3]-qq[i+1]));
	 }

	 if((xxx==1.0)&&(i==N-1))
	 {
			bsp = 1.0;
	 }
	 if((qq[i]>xxx)||(xxx>qq[i+3]))
	 {
		 bsp = 0.0 ;
	 }
 return(bsp);
}
